package Question5;

public class StringBufferBuilder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long time = System.currentTimeMillis();
		// Creating StringBuffer object
		StringBuffer buffer = new StringBuffer("Hello");
		// Modifying the string
		for (int i = 0; i < 15; i++) {
			buffer.append("World");
		}
		System.out.println("StringBuffer: " + buffer);
		System.out.println("time taken for StringBuffer: " + (System.currentTimeMillis() - time) + "ms");
		
		time = System.currentTimeMillis();
		// Creating StringBuilder object
		StringBuilder builder = new StringBuilder("How");
		 // Modifying the string
		for (int i = 0; i < 15; i++) {
			builder.append("are you!");
		}

        builder.append(" ");
        System.out.println("StringBuilder: " + builder);
		System.out.println("time taken for StringBuilder: " + (System.currentTimeMillis() -time)+ "ms");
	
		
        

       

       

	}

}
