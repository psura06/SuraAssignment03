package Question26;

public class PureSingleToneDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PureSingleton single1 = PureSingleton.getPureSingle();
        PureSingleton single2 = PureSingleton.getPureSingle();
        
        // Check if both instances are the same
        System.out.println("s1 hashcode: " + single1.hashCode());
        System.out.println("s2 hashcode: " + single2.hashCode());
        
        if (single1 == single2) {
            System.out.println("Both instances are the same");
        } else {
            System.out.println("Both instances are different");
        }
    

	}

}
