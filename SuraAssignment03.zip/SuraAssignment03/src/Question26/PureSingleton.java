package Question26;

public class PureSingleton {
	
	 private static final PureSingleton PureSingle = new PureSingleton();
	
	 public static PureSingleton getPureSingle() {
	        return PureSingle;
	    }
	    
}
