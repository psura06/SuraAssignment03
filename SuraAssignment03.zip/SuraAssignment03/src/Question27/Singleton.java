package Question27;

public class Singleton {
private static Singleton Single;

private Singleton() {
    // Private constructor to prevent external instantiation
}

public static synchronized Singleton getSingle() {
    if (Single == null) {
    	Single = new Singleton();
    }
    return Single;
}

// Other methods and properties
}

