	package Question27;

public class SingletonDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Singleton Single1 = Singleton.getSingle();
	     Singleton Single2 = Singleton.getSingle();
	        
	        // Check if both instances are the same
	        System.out.println("s1 hashcode: " + Single1.hashCode());
	        System.out.println("s2 hashcode: " + Single2.hashCode());
	        
	        if (Single1 == Single2) {
	            System.out.println("Both instances are the same");
	        } else {
	            System.out.println("Both instances are different");
	        }
	}
	
}
