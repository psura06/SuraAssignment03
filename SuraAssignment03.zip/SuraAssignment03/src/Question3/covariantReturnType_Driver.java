package Question3;

public class covariantReturnType_Driver extends covariantReturnType {
	
	@Override 
	  public String Superclass()
	  { 
	     System.out.println("subclass"); 
	      return null; 
	  } 


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		covariantReturnType CRT = new covariantReturnType_Driver(); 
	      CRT.Superclass(); 
	      covariantReturnType CRT1 = new covariantReturnType_Driver(); 
	      CRT1.Superclass();


	}

}
