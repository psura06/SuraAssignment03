package Question3;

public class covariantReturnType {
	
	public  Object Superclass()
	 { 
	   System.out.println("superclass"); 
	    return null; 
	  } 


}
