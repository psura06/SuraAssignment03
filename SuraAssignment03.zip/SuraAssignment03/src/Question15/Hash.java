package Question15;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class Hash {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 Hashtable<Integer,String> hash =new Hashtable<Integer,String>();
		 hash.put(1,"Java");
		 hash.put(2,"Python");
		 hash.put(3,"javaScript");
		 hash.put(4,"C");
	        System.out.println("*******Hash table *********");
	        for (Map.Entry m:hash.entrySet()) {
	            System.out.println(m.getKey()+"  "+m.getValue());
	        }
	 
	        HashMap<Integer,String> hash1 =new HashMap<Integer,String>();
	        hash1.put(5,"HTML");
	        hash1.put(6,"CSS"); 
	        hash1.put(7,"Bootstrap");
	        hash1.put(8,"NodeJs");
	        hash1.put(null, null);
	        System.out.println("*****Hash map**********");
	        for (Map.Entry m:hash1.entrySet()) {
	            System.out.println(m.getKey()+"  "+m.getValue());
	        }

	}

}

