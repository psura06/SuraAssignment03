package Question7;

public class Driver {
	public static final void main(String[] args) {
	    Driver obj1 = new Driver();
	}

}
