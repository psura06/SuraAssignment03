package Question2;

public class MainDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	        SubClass S = new SubClass();
	    
	        // Calling overridden methods of subclass
	        S.defaultclassMethod();   // This will call the private defaultMethod of the subclass
	        S.protectedclassMethod(); // This will call the protectedMethod of the subclass
	        S.publicclassMethod();    // This will call the publicMethod of the subclass
	    }

}