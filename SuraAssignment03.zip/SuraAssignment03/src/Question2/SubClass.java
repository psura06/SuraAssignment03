package Question2;

public class SubClass extends SuperClass{
	// Private methods cannot be overridden
    
    // Overriding default method with private access
    void defaultclassMethod() {
        System.out.println("This is a private default method.");
    }
    
    // Overriding protected method with private access
    protected void protectedclassMethod() {
        System.out.println("This is a private protected method.");
    }
    
    // Overriding public method with private access
    public void publicclassMethod() {
        System.out.println("This is a private public method.");
    }
    
    // Overriding default method with default access
    void defaultMethod() {
        System.out.println("This is a default method.");
    }
    
    // Overriding protected method with protected access
    protected void protectedMethod() {
        System.out.println("This is a protected method.");
    }
    
    // Overriding public method with public access
    public void publicMethod() {
        System.out.println("This is a public method.");
    }
}
