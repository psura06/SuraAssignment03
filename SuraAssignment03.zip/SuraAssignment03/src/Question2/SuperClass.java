package Question2;

public class SuperClass {
	private void privateClassMethod() {
        System.out.println("This is a private method.");
    }
    
    void defaultclassMethod() {
        System.out.println("This is a default method.");
    }
    
    protected void protectedclassMethod() {
        System.out.println("This is a protected method.");
    }
    
    public void publicclassMethod() {
        System.out.println("This is a public method.");
    }

}
