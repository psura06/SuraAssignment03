package Question17;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map<String, String> stateC = new HashMap<String, String>();
		stateC.put("MO", "Missouri");
		stateC.put("TX", "Texas");
		stateC.put("CA", "California");
  
        Iterator it = stateC.keySet().iterator();
  
        while (it.hasNext()) {
            System.out.println(stateC.get(it.next()));
  
            // for adding an element to Map then exception will be thrown on next call
            //cityCode.put("FL", "Florida");
        }
        
        ArrayList<Integer> List = new ArrayList<>();
        List.add(1);
        List.add(2);
        List.add(3);
        List.add(4);
        List.add(5);
  
        Iterator<Integer> itr1 = List.iterator();
        while (itr1.hasNext()) {
            if (itr1.next() == 2) {
                //it will not throw Exception
                itr1.remove();
            }
        }
  
        System.out.println(List);
  
        itr1 = List.iterator();
		

	}

}

