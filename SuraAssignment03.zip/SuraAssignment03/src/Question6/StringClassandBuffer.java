package Question6;

public class StringClassandBuffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			// Creating String Class
			String class1 = "String";
	        String class2 = "Class";
	        String class3 = class1 + " " + class2;
	        for (int i=0; i<10; i++){  
	        	
	        }  
	        long time = System.currentTimeMillis();  
	        //The main difference between the two approaches is that the 
	        //String class creates a new string every time concatenation is performed
	        System.out.println("String concatenation using String class: " + class3);
	        System.out.println("time taken for String: "+(System.currentTimeMillis()-time)+"ms");  
	        // Creating String Buffer Class
	        time = System.currentTimeMillis();
	        StringBuffer buffer1 = new StringBuffer("String");
	        StringBuffer buffer2 = new StringBuffer("Buffer");
	        StringBuffer buffer3 = buffer1.append(" ").append(buffer2);
	        //while the StringBuffer class modifies the existing StringBuffer object.
	        System.out.println("String concatenation using StringBuffer class: " + buffer3);
	        System.out.println("time taken for StringBuffer: "+(System.currentTimeMillis()-time)+"ms");  

	}

}
