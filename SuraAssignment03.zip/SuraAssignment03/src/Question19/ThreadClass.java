package Question19;

public class ThreadClass extends Thread {
	public void Threadrun()
    {
        System.out.print("Thread");
    }
    public static void main(String[] args)
    {
        ThreadClass thread = new ThreadClass(); 
        thread.start();
    }

}
