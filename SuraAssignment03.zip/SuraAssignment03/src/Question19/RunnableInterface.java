package Question19;

public class RunnableInterface implements Runnable {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RunnableInterface RI = new RunnableInterface();
        Thread thread = new Thread(RI, "r");
        
        thread.start();
        System.out.println(thread.getName());
    }
    @Override 
    public void run()
    {
        System.out.println("inside run");
    }
}
