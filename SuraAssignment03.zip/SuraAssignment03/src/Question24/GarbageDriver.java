package Question24;

import java.util.ArrayList;
import java.util.List;

public class GarbageDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Runtime get1 = Runtime.getRuntime();
	        for (int i=0; i<= 100000; i++) {
	            List<Integer> list = new ArrayList<>();
	            list.add(1);
	            list.add(2);
	            list.add(3);
	        }
	        System.out.println("Memory before invoking the Garbage Collector using system GC : " + get1.freeMemory());
	        System.gc();
	        System.out.println("Memory after invoking the Garbage Collector using system GC : " + get1.freeMemory());
		
		Runtime get2 = Runtime.getRuntime();
     for (int i=0; i<= 100000; i++) {
         List<Integer> list = new ArrayList<>();
         list.add(1);
         list.add(2);
         list.add(3);
     }
     System.out.println("Memory before invoke Garbage Collector using runtime class method : " + get2.freeMemory());
     get2.gc();
     System.out.println("Memory after invoke the Garbage Collector using runtime class method : " + get2.freeMemory());

	}

}
