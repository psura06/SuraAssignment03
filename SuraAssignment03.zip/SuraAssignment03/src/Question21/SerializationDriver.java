package Question21;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class SerializationDriver {
		int id;  
		String name;  
		public SerializationDriver(int id, String name) {  
		  this.id = id;  
		  this.name = name;  
		 }  

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			
			try{       
				SerializationDriver SD =new SerializationDriver(1,"john");    
				
				  FileOutputStream fileout=new FileOutputStream("file.txt");    
				  ObjectOutputStream objectout=new ObjectOutputStream(fileout); 
				  
				  objectout.writeObject(SD);    
				  objectout.flush();      
				  objectout.close();    
				  System.out.println("Done");    
				  }
			catch(Exception e){
				System.out.println(e);
				  }    
				 }   

	}
