package Question10;

public class Superclass {
	void method() {
	    System.out.println("Super");
	  }
	void msg() {
		System.out.println("hello");
	}

}
