package Question10;

public class Subclass extends Superclass{

		
		void msg() throws ArithmeticException {
			System.out.println("Hi");
		}
		 
		  // Driver code
		  public static void main(String args[]) {
		    Superclass ac = new Subclass();
		    ac.method();
		    ac.msg();

	}
}
