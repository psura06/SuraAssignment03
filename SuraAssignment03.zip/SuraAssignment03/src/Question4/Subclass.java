package Question4;

public class Subclass extends Superclass{
	public void SuperMethod() {
		System.out.println("subclass");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Superclass S = new Subclass();
		//S.SuperMethod();// Trying to override the private method in superclass
		//S.Wishes(); // Trying to override the static method in superclass
	}
}
