package Question4;

public class Superclass {
	private void SuperMethod() {
	      System.out.println("Super Class");    
	   }
	static void Wishes() {
		System.out.println("Hello");
	}


}
