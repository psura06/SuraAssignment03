package Question1;

public class Generics<T> {
	private T define;
	
	public Generics(T define) {
		this.define = define;
	}
	public T getDefine() {
		return this.define;
	}
	
	public void setDefine(T define) {
		this.define = define;
	}
	

}
