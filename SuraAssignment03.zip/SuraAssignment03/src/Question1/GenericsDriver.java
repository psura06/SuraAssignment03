package Question1;

public class GenericsDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Integer Type
		Generics<Integer> GenInt = new Generics<Integer>(10);
		System.out.println(GenInt.getDefine());

		//String Type
		Generics<String> GenStr = new Generics<String>("java");
		System.out.println(GenStr.getDefine());
	}

}
