package Question22;

public class imMutableDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str= "Java";  
		   str.concat(" Script");
		   System.out.println(str); 
		 }  

}
